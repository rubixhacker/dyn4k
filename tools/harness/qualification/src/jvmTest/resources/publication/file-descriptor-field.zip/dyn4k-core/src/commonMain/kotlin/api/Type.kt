// Fixture notice
package api
class Type
