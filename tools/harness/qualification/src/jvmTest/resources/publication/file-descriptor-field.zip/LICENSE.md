Fixture license
