/*
 * Copyright (c) 2010-2026 William Bittle  http://www.dyn4j.org/
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are permitted 
 * provided that the following conditions are met:
 * 
 *   * Redistributions of source code must retain the above copyright notice, this list of conditions 
 *     and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice, this list of conditions 
 *     and the following disclaimer in the documentation and/or other materials provided with the 
 *     distribution.
 *   * Neither the name of the copyright holder nor the names of its contributors may be used to endorse or 
 *     promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.dyn4j.simulation;
import org.dyn4j.calibration.Bridge;

import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.dynamics.joint.WeldJoint;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;
import org.dyn4j.world.World;
import org.junit.Test;

import junit.framework.TestCase;

/**
 * Used to test the {@link WeldJoint} class in simulation.
 * @author William Bittle
 * @version 6.0.0
 * @since 4.2.0
 */
public class WeldJointSimulationTest {
	/**
	 * Tests the body separation as enforced by the distance joint.
	 */
	@Test
	public void standard() {
		World<Body> w = new World<Body>();
		
		// take friction and damping out of the picture
		
		Body g = new Body();
		BodyFixture gf = g.addFixture(Geometry.createRectangle(10.0, 0.5));
		Bridge.record("source-action", "gf.setFriction(0.0);");
		gf.setFriction(0.0);
		Bridge.record("source-action", "g.setMass(MassType.INFINITE);");
		g.setMass(MassType.INFINITE);
		Bridge.record("source-action", "g.setLinearDamping(0.0);");
		g.setLinearDamping(0.0);
		Bridge.record("source-action", "g.setAngularDamping(0.0);");
		g.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(g);");
		w.addBody(g);
		
		Body b = new Body();
		BodyFixture bf = b.addFixture(Geometry.createRectangle(1.0, 0.5));
		Bridge.record("source-action", "bf.setFriction(0.0);");
		bf.setFriction(0.0);
		Bridge.record("source-action", "b.setMass(MassType.NORMAL);");
		b.setMass(MassType.NORMAL);
		Bridge.record("source-action", "b.translate(0.0, 2.0);");
		b.translate(0.0, 2.0);
		Bridge.record("source-action", "b.setLinearDamping(0.0);");
		b.setLinearDamping(0.0);
		Bridge.record("source-action", "b.setAngularDamping(0.0);");
		b.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(b);");
		w.addBody(b);
		
		WeldJoint<Body> wj = new WeldJoint<Body>(g, b, b.getWorldCenter());
		Bridge.record("source-action", "w.addJoint(wj);");
		w.addJoint(wj);

		double invdt = w.getTimeStep().getInverseDeltaTime();
		
		Bridge.step(w, 4);
		
		// because the allowed axis is the x-axis and the position of the axis is at body2's world center
		// gravity is applied but has no effect
		Vector2 v2 = b.getWorldCenter();
		TestCase.assertEquals(0.0, v2.x);
		TestCase.assertEquals(2.0, v2.y);
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(4.9000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
		
		// apply some velocity along the y-axis
		Bridge.record("source-action", "b.setLinearVelocity(0.0, 1.0);");
		b.setLinearVelocity(0.0, 1.0);
		Bridge.step(w, 4);
		
		// still nothing should happen
		v2 = b.getWorldCenter();
		TestCase.assertEquals(0.0, v2.x);
		TestCase.assertEquals(2.0, v2.y);
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(4.9000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
		
		// now apply some velocity along the x-axis
		Bridge.record("source-action", "b.setLinearVelocity(1.0, 1.0);");
		b.setLinearVelocity(1.0, 1.0);
		Bridge.step(w, 4);
		
		// still nothing should happen
		v2 = b.getWorldCenter();
		TestCase.assertEquals(0.0, v2.x);
		TestCase.assertEquals(2.0, v2.y);
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(4.9000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
		
		Bridge.record("source-action", "b.applyTorque(Math.toRadians(30));");
		b.applyTorque(Math.toRadians(30));
		Bridge.step(w, 1);
		
		// still nothing should happen
		v2 = b.getWorldCenter();
		TestCase.assertEquals(0.0, v2.x);
		TestCase.assertEquals(2.0, v2.y);
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(0.0, b.getTransform().getRotationAngle(), 1e-5);
		TestCase.assertEquals(-0.52359, wj.getReactionTorque(invdt), 1e-5);
		TestCase.assertEquals(4.9000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
	}
	
	/**
	 * Tests the bodies with an angular spring
	 */
	@Test
	public void softConstraint() {
		World<Body> w = new World<Body>();
		// take gravity out the picture
		
		// take friction and damping out of the picture
		
		Body g = new Body();
		BodyFixture gf = g.addFixture(Geometry.createRectangle(10.0, 0.5));
		Bridge.record("source-action", "gf.setFriction(0.0);");
		gf.setFriction(0.0);
		Bridge.record("source-action", "g.setMass(MassType.INFINITE);");
		g.setMass(MassType.INFINITE);
		Bridge.record("source-action", "g.setLinearDamping(0.0);");
		g.setLinearDamping(0.0);
		Bridge.record("source-action", "g.setAngularDamping(0.0);");
		g.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(g);");
		w.addBody(g);
		
		Body b = new Body();
		BodyFixture bf = b.addFixture(Geometry.createRectangle(1.0, 0.5));
		Bridge.record("source-action", "bf.setFriction(0.0);");
		bf.setFriction(0.0);
		Bridge.record("source-action", "b.setMass(MassType.NORMAL);");
		b.setMass(MassType.NORMAL);
		Bridge.record("source-action", "b.translate(0.0, 2.0);");
		b.translate(0.0, 2.0);
		Bridge.record("source-action", "b.setLinearDamping(0.0);");
		b.setLinearDamping(0.0);
		Bridge.record("source-action", "b.setAngularDamping(0.0);");
		b.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(b);");
		w.addBody(b);
		
		Vector2 p = b.getWorldCenter().sum(-0.5, 0.0);
		WeldJoint<Body> wj = new WeldJoint<Body>(g, b, p);
		
		// NOTE: that I've set the rest distance to more than the limits
		Bridge.record("source-action", "wj.setSpringEnabled(true);");
		wj.setSpringEnabled(true);
		Bridge.record("source-action", "wj.setSpringDamperEnabled(true);");
		wj.setSpringDamperEnabled(true);
		Bridge.record("source-action", "wj.setSpringDampingRatio(0.3);");
		wj.setSpringDampingRatio(0.3);
		Bridge.record("source-action", "wj.setSpringFrequency(8.0);");
		wj.setSpringFrequency(8.0);
		Bridge.record("source-action", "w.addJoint(wj);");
		w.addJoint(wj);
		
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(0.0, b.getTransform().getRotationAngle(), 1e-5);

		// do one simulation step, this should cause body2 to drop due to the soft constraint
		// and have a negative torque
		Bridge.step(w, 1);
		
		double invdt = w.getTimeStep().getInverseDeltaTime();
		
		TestCase.assertEquals(-0.17027, b.getAngularVelocity(), 1e-3);
		TestCase.assertEquals(-0.00283, b.getTransform().getRotationAngle(), 1e-3);
		TestCase.assertEquals( 0.63542, wj.getSpringTorque(invdt), 1e-3);
		TestCase.assertEquals( 0.63542, wj.getReactionTorque(invdt), 1e-3);
		TestCase.assertEquals( 2.33825, wj.getReactionForce(invdt).getMagnitude(), 1e-3);
		
		// after a few more simulations it should stabilize with rotation below the x-axis
		Bridge.step(w, 20);
		
		TestCase.assertEquals(-0.01919, b.getAngularVelocity(), 1e-5);
		TestCase.assertEquals(-0.01884, b.getTransform().getRotationAngle(), 1e-5);
		TestCase.assertEquals( 2.50980, wj.getSpringTorque(invdt), 1e-5);
		TestCase.assertEquals( 2.50980, wj.getReactionTorque(invdt), 1e-5);
		TestCase.assertEquals( 4.98500, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
		
		// test the maximum torque setting
		Bridge.record("source-action", "wj.setMaximumSpringTorque(5);");
		wj.setMaximumSpringTorque(5);
		Bridge.record("source-action", "wj.setMaximumSpringTorqueEnabled(true);");
		wj.setMaximumSpringTorqueEnabled(true);
		Bridge.record("source-action", "b.applyForce(new Vector2(0.0, -10.0), new Vector2(0.5, 2.0));");
		b.applyForce(new Vector2(0.0, -10.0), new Vector2(0.5, 2.0));
		Bridge.step(w, 1);
		
		TestCase.assertEquals(-0.72033, b.getAngularVelocity(), 1e-5);
		TestCase.assertEquals(-0.03084, b.getTransform().getRotationAngle(), 1e-5);
		TestCase.assertEquals( 5.00000, wj.getSpringTorque(invdt), 1e-5);
		TestCase.assertEquals( 5.00000, wj.getReactionTorque(invdt), 1e-5);
		TestCase.assertEquals( 4.38931, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
	}

	/**
	 * Tests the bodies not exceeding the limits
	 */
	@Test
	public void softConstraintWithLimitsLower() {
		World<Body> w = new World<Body>();
		// take gravity out the picture
		
		// take friction and damping out of the picture
		
		Body g = new Body();
		BodyFixture gf = g.addFixture(Geometry.createRectangle(10.0, 0.5));
		Bridge.record("source-action", "gf.setFriction(0.0);");
		gf.setFriction(0.0);
		Bridge.record("source-action", "g.setMass(MassType.INFINITE);");
		g.setMass(MassType.INFINITE);
		Bridge.record("source-action", "g.setLinearDamping(0.0);");
		g.setLinearDamping(0.0);
		Bridge.record("source-action", "g.setAngularDamping(0.0);");
		g.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(g);");
		w.addBody(g);
		
		Body b = new Body();
		BodyFixture bf = b.addFixture(Geometry.createRectangle(1.0, 0.5));
		Bridge.record("source-action", "bf.setFriction(0.0);");
		bf.setFriction(0.0);
		Bridge.record("source-action", "b.setMass(MassType.NORMAL);");
		b.setMass(MassType.NORMAL);
		Bridge.record("source-action", "b.translate(0.0, 2.0);");
		b.translate(0.0, 2.0);
		Bridge.record("source-action", "b.setLinearDamping(0.0);");
		b.setLinearDamping(0.0);
		Bridge.record("source-action", "b.setAngularDamping(0.0);");
		b.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(b);");
		w.addBody(b);
		
		Vector2 p = b.getWorldCenter().sum(-0.5, 0.0);
		WeldJoint<Body> wj = new WeldJoint<Body>(g, b, p);
		
		// NOTE: that I've set the rest distance to more than the limits
		Bridge.record("source-action", "wj.setSpringEnabled(true);");
		wj.setSpringEnabled(true);
		Bridge.record("source-action", "wj.setSpringDamperEnabled(true);");
		wj.setSpringDamperEnabled(true);
		Bridge.record("source-action", "wj.setSpringDampingRatio(0.3);");
		wj.setSpringDampingRatio(0.3);
		Bridge.record("source-action", "wj.setSpringFrequency(8.0);");
		wj.setSpringFrequency(8.0);
		
		double lim = Math.PI * 0.2;
		Bridge.record("source-action", "wj.setLimitsEnabled(-lim, lim);");
		wj.setLimitsEnabled(-lim, lim);
		
		Bridge.record("source-action", "w.addJoint(wj);");
		w.addJoint(wj);
		
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(0.0, b.getTransform().getRotationAngle(), 1e-5);

		double invdt = w.getTimeStep().getInverseDeltaTime();
		
		// too weak to hold up the object, so it should rest on the limit
		Bridge.record("source-action", "wj.setMaximumSpringTorque(1);");
		wj.setMaximumSpringTorque(1);
		Bridge.record("source-action", "wj.setMaximumSpringTorqueEnabled(true);");
		wj.setMaximumSpringTorqueEnabled(true);
//		b.applyForce(new Vector2(0.0, -10.0), new Vector2(0.5, 2.0));
		Bridge.step(w, 50);
		
		TestCase.assertEquals( 0.00000, b.getAngularVelocity(), 1e-5);
		TestCase.assertEquals(-lim, b.getTransform().getRotationAngle(), 1e-3);
		TestCase.assertEquals( 1.00000, wj.getSpringTorque(invdt), 1e-5);
		TestCase.assertEquals( 1.98177, wj.getReactionTorque(invdt), 1e-5);
		TestCase.assertEquals( 4.90000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
	}
	
	/**
	 * Tests the bodies not exceeding the limits
	 */
	@Test
	public void softConstraintWithLimitsUpper() {
		World<Body> w = new World<Body>();
		// take gravity out the picture
		
		// take friction and damping out of the picture
		
		Body g = new Body();
		BodyFixture gf = g.addFixture(Geometry.createRectangle(10.0, 0.5));
		Bridge.record("source-action", "gf.setFriction(0.0);");
		gf.setFriction(0.0);
		Bridge.record("source-action", "g.setMass(MassType.INFINITE);");
		g.setMass(MassType.INFINITE);
		Bridge.record("source-action", "g.setLinearDamping(0.0);");
		g.setLinearDamping(0.0);
		Bridge.record("source-action", "g.setAngularDamping(0.0);");
		g.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(g);");
		w.addBody(g);
		
		Body b = new Body();
		BodyFixture bf = b.addFixture(Geometry.createRectangle(1.0, 0.5));
		Bridge.record("source-action", "bf.setFriction(0.0);");
		bf.setFriction(0.0);
		Bridge.record("source-action", "b.setMass(MassType.NORMAL);");
		b.setMass(MassType.NORMAL);
		Bridge.record("source-action", "b.translate(0.0, 2.0);");
		b.translate(0.0, 2.0);
		Bridge.record("source-action", "b.setLinearDamping(0.0);");
		b.setLinearDamping(0.0);
		Bridge.record("source-action", "b.setAngularDamping(0.0);");
		b.setAngularDamping(0.0);
		Bridge.record("source-action", "w.addBody(b);");
		w.addBody(b);
		
		Vector2 p = b.getWorldCenter().sum(0.5, 0.0);
		WeldJoint<Body> wj = new WeldJoint<Body>(g, b, p);
		
		// NOTE: that I've set the rest distance to more than the limits
		Bridge.record("source-action", "wj.setSpringEnabled(true);");
		wj.setSpringEnabled(true);
		Bridge.record("source-action", "wj.setSpringDamperEnabled(true);");
		wj.setSpringDamperEnabled(true);
		Bridge.record("source-action", "wj.setSpringDampingRatio(0.3);");
		wj.setSpringDampingRatio(0.3);
		Bridge.record("source-action", "wj.setSpringFrequency(8.0);");
		wj.setSpringFrequency(8.0);
		
		double lim = Math.PI * 0.2;
		Bridge.record("source-action", "wj.setLimitsEnabled(-lim, lim);");
		wj.setLimitsEnabled(-lim, lim);
		
		Bridge.record("source-action", "w.addJoint(wj);");
		w.addJoint(wj);
		
		TestCase.assertEquals(0.0, b.getAngularVelocity());
		TestCase.assertEquals(0.0, b.getTransform().getRotationAngle(), 1e-5);

		double invdt = w.getTimeStep().getInverseDeltaTime();
		
		// too weak to hold up the object, so it should rest on the limit
		Bridge.record("source-action", "wj.setMaximumSpringTorque(1);");
		wj.setMaximumSpringTorque(1);
		Bridge.record("source-action", "wj.setMaximumSpringTorqueEnabled(true);");
		wj.setMaximumSpringTorqueEnabled(true);
		Bridge.record("source-action", "b.applyForce(new Vector2(0.0, -10.0), new Vector2(-0.5, 2.0));");
		b.applyForce(new Vector2(0.0, -10.0), new Vector2(-0.5, 2.0));
		Bridge.step(w, 50);
		
		TestCase.assertEquals( 0.00000, b.getAngularVelocity(), 1e-5);
		TestCase.assertEquals( lim, b.getTransform().getRotationAngle(), 1e-3);
		TestCase.assertEquals(-1.00000, wj.getSpringTorque(invdt), 1e-5);
		TestCase.assertEquals(-1.98177, wj.getReactionTorque(invdt), 1e-5);
		TestCase.assertEquals( 4.90000, wj.getReactionForce(invdt).getMagnitude(), 1e-5);
	}
}
